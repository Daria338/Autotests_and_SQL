URL_SERVICE = "https://d55b9a4b-1b76-4b35-a090-b0f7288347b0.serverhub.praktikum-services.ru"
CREATE_ORDER_PATH = "/api/v1/orders"
GET_ORDER_PATH = "/api/v1/orders/track"